'use client';
import React from "react";

export default function Home() {
  return (
    <main className="min-h-screen bg-white text-gray-900 font-sans">
      {/* Hero Section */}
      <section className="bg-green-600 text-white py-20 px-6 text-center shadow-md">
        <h1 className="text-5xl font-bold mb-4">Derry Prendiville</h1>
        <p className="text-xl">BER Assessor & Energy Consultant</p>
        <p className="mt-4 text-lg">Helping homes and businesses across Kerry & Munster improve energy performance</p>
        <img src="/images/ber-banner.jpg" alt="BER Certificate" width="800" height="400" className="mx-auto mt-8 rounded-lg" />
      </section>

      {/* Why Get a BER Section */}
      <section className="py-16 px-8 max-w-6xl mx-auto">
        <h2 className="text-3xl font-semibold text-center mb-6">Why Get a BER Certificate?</h2>
        <div className="grid md:grid-cols-3 gap-6 text-center">
          <div className="bg-gray-100 p-6 rounded-xl shadow-sm">
            <h3 className="text-xl font-semibold mb-2">Legal Requirement</h3>
            <p>Mandatory when selling or renting a property in Ireland.</p>
          </div>
          <div className="bg-gray-100 p-6 rounded-xl shadow-sm">
            <h3 className="text-xl font-semibold mb-2">Energy Cost Savings</h3>
            <p>Identify improvements that reduce heating bills and boost comfort.</p>
          </div>
          <div className="bg-gray-100 p-6 rounded-xl shadow-sm">
            <h3 className="text-xl font-semibold mb-2">Access Grants</h3>
            <p>Qualify for SEAI grants and retrofit supports with up-to-date BER ratings.</p>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 px-8 bg-gray-50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-semibold mb-6">About Derry</h2>
          <img src="/images/derry-profile.jpg" alt="Derry Prendiville" width="200" height="200" className="rounded-full mx-auto mb-4" />
          <p className="text-lg mb-4">
            I’m a SEAI-registered BER Assessor and qualified Architectural Technologist based in Tralee,
            Co. Kerry. With experience in energy consultancy and retrofit guidance, I help homeowners
            and businesses across Munster understand their building’s energy performance and access
            improvement grants.
          </p>
          <p className="text-lg">
            I pride myself on delivering quick, accurate, and practical assessments, tailored to each
            client’s goals—whether for compliance, comfort, or cost-saving.
          </p>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 px-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-semibold mb-6 text-center">Services</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-6 border rounded-xl shadow">
              <h3 className="text-xl font-bold mb-2">Domestic & Commercial BER Certificates</h3>
              <p>Certified assessments for sales, rentals, and new builds across Munster.</p>
            </div>
            <div className="bg-white p-6 border rounded-xl shadow">
              <h3 className="text-xl font-bold mb-2">Post-Retrofit Evaluations</h3>
              <p>Verify energy improvements for grant compliance and heat pump readiness.</p>
            </div>
            <div className="bg-white p-6 border rounded-xl shadow">
              <h3 className="text-xl font-bold mb-2">SEAI Technical Assessments</h3>
              <p>Support for Better Energy Homes grants, heat pump grants, and more.</p>
            </div>
            <div className="bg-white p-6 border rounded-xl shadow">
              <h3 className="text-xl font-bold mb-2">Retrofit Advice</h3>
              <p>Guidance on insulation, ventilation, heating upgrades, and energy efficiency strategies.</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 px-8 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-semibold text-center mb-6">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <div>
              <h4 className="text-lg font-semibold">What is a BER?</h4>
              <p>BER (Building Energy Rating) is an energy label with accompanying advisory report for homes and buildings, required when selling or renting in Ireland.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold">How long does a BER assessment take?</h4>
              <p>Most assessments take 1–2 hours onsite, with a full report delivered within 24–48 hours.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold">How much does it cost?</h4>
              <p>Prices vary based on property size and location. Get in touch for a free quote.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold">What do I need to prepare?</h4>
              <p>Ensure access to all rooms, attic hatch, boiler, and heating controls. Construction plans can help but aren't essential.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-semibold mb-6">Client Testimonials</h2>
          <blockquote className="italic text-gray-700 mb-6">“Derry was professional, punctual, and explained everything clearly. Got our BER certificate within a day.” <br />– Mary O., Killarney</blockquote>
          <blockquote className="italic text-gray-700">“Highly recommend! Helped us qualify for SEAI grants and guided us through the retrofit process.” <br />– Liam D., Limerick</blockquote>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 px-8 bg-green-50">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-semibold mb-4">Contact</h2>
          <p className="mb-2">📍 Tralee, Co. Kerry – Serving the Munster Region</p>
          <p className="mb-2">📧 <a href="mailto:dparchtech@gmail.com" className="text-green-700 font-semibold">dparchtech@gmail.com</a></p>
          <p className="mb-6">📞 <a href="tel:+353863712524" className="text-green-700 font-semibold">+353 86 371 2524</a></p>
          <a href="mailto:dparchtech@gmail.com" className="inline-block bg-green-600 text-white px-6 py-3 rounded-full font-bold hover:bg-green-700 transition">Get Your BER Quote</a>
        </div>
      </section>
    </main>
  );
}
